#include "ListOfDoublyLinkedNodes.h"

Node * ListOfDoublyLinkedNodes :: obtain (Node *place)
{
	// to be implemented
	return(NULL);
}
