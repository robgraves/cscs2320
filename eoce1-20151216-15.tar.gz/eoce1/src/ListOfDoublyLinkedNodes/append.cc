#include "ListOfDoublyLinkedNodes.h"

void ListOfDoublyLinkedNodes :: append(Node *place, Node *newNode)
{
	// to be implemented
}
