#include "ListOfDoublyLinkedNodes.h"

Node * ListOfDoublyLinkedNodes :: find(int value)
{
	// to be implemented
	return(NULL);
}
