#include <ListOfSinglyLinkedNodes.h>

List * ListOfSinglyLinkedNodes :: copy()
{
	// Your implementation here
    return (NULL);
}
