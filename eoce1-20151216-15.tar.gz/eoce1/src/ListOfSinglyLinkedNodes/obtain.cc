#include "ListOfSinglyLinkedNodes.h"

Node * ListOfSinglyLinkedNodes :: obtain (Node *place)
{
	// to be implemented
	return(NULL);
}
