#include "ListOfSinglyLinkedNodes.h"

// needs to properly handle invalid list positions ( < 0)
Node * ListOfSinglyLinkedNodes :: setListPosition(int pos)
{
	// to be implemented
	return(NULL);
}

// Needs to handle improper place pointers (ie NULL)
int ListOfSinglyLinkedNodes :: getListPosition(Node *place)
{
	// to be implemented
	return(-1);
}
