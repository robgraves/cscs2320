#include "ListOfSinglyLinkedNodes.h"

void ListOfSinglyLinkedNodes :: append(Node *place, Node *newNode)
{
	// to be implemented
}
