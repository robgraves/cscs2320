#include "ListOfSinglyLinkedNodes.h"

// insert() - insert newNode before place in this
//
void ListOfSinglyLinkedNodes :: insert(Node *place, Node *newNode)
{
	// Your implementation here
}
