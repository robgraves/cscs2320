#include "ListOfSinglyLinkedNodes.h"

Node * ListOfSinglyLinkedNodes :: find(int value)
{
	// to be implemented
	return(NULL);
}
