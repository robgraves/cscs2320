#include <List.h>

int  List :: getQuantity()
{
	return (this -> quantity);
}

void List :: setQuantity(int quantity)
{
	this -> quantity = quantity;
}
