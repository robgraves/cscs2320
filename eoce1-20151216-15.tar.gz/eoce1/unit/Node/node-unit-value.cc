#include <cstdio>
#include <cstdlib>
#include "ListOfDoublyLinkedNodes.h"

int main()
{
	return(0);
}
