#include <stdio.h>
#include "list.h"

int main()
{
	// your implementation here
	return(0);
}
