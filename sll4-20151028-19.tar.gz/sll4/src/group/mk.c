#include "group.h"

//////////////////////////////////////////////////////////////////////
//
// mkgroup() - a group library function to allocate and initialize a 
//             new group.
//
//   behavior: on error, return NULL.
//
//       note: you are to have only ONE return statement for this
//             entire function. Change the existing one as needed.
//
Group *mkgroup(void)
{
	// your implementation here (please remove this comment when done)
	return(NULL);
}
